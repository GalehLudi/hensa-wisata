package com.hensa.wisata.libs;

public class API {
    public static final String BASE_URL = "http://192.168.236.219:8001";
    public static final String API_URL = BASE_URL + "/api/";
}
