<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LaporanController;

Route::get('/laporan', LaporanController::class);

Route::get('/', function () {
    return base64_encode(file_get_contents(public_path('image/kop.jpg')));
});
